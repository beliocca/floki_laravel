<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Discount;
use Faker\Generator as Faker;

$factory->define(Discount::class, function (Faker $faker) {
    return [
        //
    ];
});
