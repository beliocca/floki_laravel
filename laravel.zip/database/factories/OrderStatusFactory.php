<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\OrderStatus;
use Faker\Generator as Faker;

$factory->define(OrderStatus::class, function (Faker $faker) {
    return [
        //
    ];
});
