<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

// use App\ProductCategory;
// use Faker\Generator as Faker;

// $factory->define(ProductCategory::class, function (Faker $faker) {
//     return [
//       'category_id' => $faker->numberBetween(1, 6),
//       'product_id' => $faker->numberBetween(1, 60)
//
//     ];
// });
