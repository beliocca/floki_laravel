// carousel home


//
//
// setInterval(function () {
//         changePhoto();
//     }, 3000);
//
// var arrayPhotos = ['']
//
// function changePhoto(){
//
//
// }

// var body =  document.querySelector("body");
//    var parallax = document.querySelector(".home-parallax");
//    var backgrounds = new Array("url(/images/parallax/home/1.jpg)",
//    "url(/images/parallax/home/8.jpg)",
//    "url(/images/parallax/home/5.jpg)",
//    "url(/images/parallax/home/4.jpg)"
//    );
//    var current = 0;
//
//    function nextBackground() {
//      parallax.style.backgroundImage =  backgrounds[current];
//      if (current < backgrounds.length) {
//         current++
//      } else { current = 0;}
//
//  }
//
//
//
// setInterval(function(){ nextBackground() }, 2000)
