<?php $__env->startSection('title', 'Mi Perfil - FLOKI Deco & Design'); ?>


<?php $__env->startSection('content'); ?>



<div class="container perfil">
    <div class="row">
        <div class="col-12 col-sm-4 ">
            <h2 class="h2perfil">cuenta</h2>
            <ul>
                <li>
                    <a class="listperfil" href="">perfil</a>
                </li>
                <li>
                    <a class="listperfil" href="">historial de ordenes</a>
                </li>
                <li>
                    <a class="listperfil" href="">direcciones guardadas</a>
                </li>
            </ul>
        </div>
        <div class="col-12 col-sm-8">
            <h2 class="h2perfil">perfil</h2>
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div>
                    <label for="name">Nombre</label>
                    <input id="name" class="userform form-control" type="text" name="name" value="" autofocus
                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <?php if(isset($message)): ?> placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?>
                        placeholder="<?php echo e($user->name); ?>" <?php endif; ?>>
                </div>
                <div>
                    <label for="last_name">Apellido</label>
                    <input id="last_name" class="userform form-control" type="text" name="last_name" value="" autofocus
                        <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> <?php if(isset($message)): ?> placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?>
                        placeholder="<?php echo e($user->last_name); ?>" <?php endif; ?>>
                </div>

                <div>
                    <label for="phone">Telefono</label>
                <input id="phone" class="userform form-control" type="number" name="phone" value="" placeholder="<?php echo e($user->phone); ?>" autofocus>
                    <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                    <small class="tyc"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                </div>
                <div>
                    <label for="birthday">Cumpleaños</label>
                    <input id="birthday" class="userform form-control" type="date" name="birthday"
                        value="" placeholder="<?php echo e($user->birthday); ?>"autocomplete="birthday" autofocus>
                    <?php if ($errors->has('birthday')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birthday'); ?>
                    <?php if(isset($message)): ?>
                    <small class="tyc"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <?php endif; ?>
                </div>

                <button type="submit">Actualizar</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/profile.blade.php ENDPATH**/ ?>