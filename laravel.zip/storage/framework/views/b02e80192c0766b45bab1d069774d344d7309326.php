<?php $__env->startSection('title', 'Admin - FLOKI Deco & Design'); ?>

<?php $__env->startSection('content'); ?>



<div class="container perfil">
    <div class="row">
        <div class="col-12 col-sm-4 ">
            <h2 class="h2perfil">admin</h2>
            <ul>
                <li>
                    <a class="listperfil" href="/admin/productlist"> productos</a>
                </li>
                <li>
                    <a class="listperfil" href="">categorias</a>
                </li>
                <li>
                    <a class="listperfil" href="">ordenes</a>
                </li>
                <li>
                    <a class="listperfil" href="">usuarios</a>
                </li>
            </ul>
        </div>
        <div class="col-12 col-sm-8">
            <h2 class="h2perfil">Agregar Productos</h2>
            <form action="/admin/addproduct" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="name">Nombre</label>
                    <input class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>" >
                </div>
                <div>
                    <label for="price">Precio</label>
                    <input class="form-control" type="number" name="price" value="<?php echo e(old('price')); ?>">
                </div>
                <div>
                    <label for="category">Categoria</label>
                    <select class="form-control" type="select" name="category" value="<?php echo e(old('category')); ?>">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="stock">Unidades</label>
                    <input class="form-control" type="number" name="stock" value="<?php echo e(old('stock')); ?>">
                </div>
                <div>
                    <label for="description">Descripcion</label>
                    <input class="form-control" type="textarea" name="description" value="<?php echo e(old('description')); ?>">
                </div>
                <div>
                    <label for="filename">Imagenes</label>
                    <input class="form-control" type="file" name="filename" value="<?php echo e(old('filename')); ?>">
                </div>
                <button type="submit">CREAR</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/admin.blade.php ENDPATH**/ ?>