<?php $__env->startSection('title', 'Checkout - FLOKI Deco & Design'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="titleperfil">Checkout</h1>
<div>
    <h2>Productos</h2>
    <ul>
        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li><span><?php echo e($cart->quantity); ?> <?php echo e($cart->product->name); ?>

            </span><span>$<?php echo e($cart->product->price*$cart->quantity); ?></span></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>



<form action="/order" method="POST">
    <?php echo csrf_field(); ?>


    <input type="hidden" value="<?php echo e($carts); ?>" name="carts">
    <h2>Tus datos</h2>
    <label for="name">Nombre</label>
    <input class="form-control " type="text" value="<?php echo e($user->name); ?>" name="name" placeholder="<?php echo e($user->name); ?>">
    <label for="last_name">Apellido</label>
    <input class="form-control " type="text" value="<?php echo e($user->last_name); ?>" name="last_name" placeholder="<?php echo e($user->last_name); ?>">

    <?php if(Auth::user()): ?>
    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
    <input type="hidden" name="email" value="<?php echo e($user->email); ?>">
    <?php else: ?>
    <label for="email">email</label>
    <input class="form-control " type="email" value="" name="email">
    <?php endif; ?>
    <label for="address_line1">Direccion </label>
    <input class="form-control " type="text" value="" name="address_line1" <?php if($user->addresses->first()): ?> placeholder="<?php echo e($user->addresses->first()->address_line1); ?>" <?php endif; ?> >
    <input class="form-control " type="text" value="" name="address_line2" <?php if($user->addresses->first()): ?> placeholder="<?php echo e($user->addresses->first()->address_line2); ?>" <?php endif; ?>>
    <label for="city">Ciudad</label>
    <input class="form-control " type="text" value="" name="city"  <?php if($user->addresses->first()): ?> placeholder="<?php echo e($user->addresses->first()->city); ?>" <?php endif; ?>>
    <label for="zipcode">Código postal</label>
    <input class="form-control " type="text" value="" name="zipcode"  <?php if($user->addresses->first()): ?> placeholder="<?php echo e($user->addresses->first()->zipcode); ?>" <?php endif; ?>>
    <label for="state">Provincia</label>
    <input class="form-control " type="text" value="" name="state"  <?php if($user->addresses->first()): ?> placeholder="<?php echo e($user->addresses->first()->state); ?>" <?php endif; ?>>
    <label for="contry">Pais</label>
    <input class="form-control " type="text" value="" name="country"  <?php if($user->addresses->first()): ?> placeholder="<?php echo e($user->addresses->first()->country); ?>" <?php endif; ?>>

    <button type="submit">Comprar</button>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\floki_laravel\resources\views/checkout.blade.php ENDPATH**/ ?>