<?php $__env->startSection('title', 'FLOKI Deco & Design'); ?>


<?php $__env->startSection('content'); ?>


  <div class="home-stripe">
    <h1>NEW COLLECTION FALL-WINTER '19 // NEW COLLECTION FALL-WINTER '19 // NEW COLLECTION FALL-WINTER '19 </h1>
  </div>

<h1>SOBRE FLOKI</h1>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur nibh diam, suscipit ac sodales ac, venenatis vel dui. Fusce vel nisl in ligula aliquet lacinia non at ipsum. Nunc ex sem, pharetra non accumsan sed, dictum non neque. Donec iaculis libero eu metus fringilla condimentum. Nulla ipsum mauris, posuere sollicitudin varius et, ultrices eu metus. Mauris nisi massa, tincidunt id gravida non, elementum eget tortor. Proin sit amet arcu ut odio cursus efficitur quis eget elit. Pellentesque et accumsan nulla. Curabitur cursus semper est. Integer efficitur orci sit amet ipsum tempus, at consequat velit placerat. Etiam vitae neque orci. Donec malesuada diam lectus, nec dictum nisi blandit ac.
</p>

<p>
Aenean ultrices orci at tincidunt pellentesque. Nullam ut auctor metus. Curabitur eu ullamcorper nisi. Nam quis neque tempor nulla semper venenatis ut ut lorem. Mauris non tellus a ex vestibulum rutrum fringilla in augue. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam vitae neque arcu. Fusce lacinia dui vel odio feugiat, at elementum nulla hendrerit. Suspendisse mattis magna vitae semper faucibus. Maecenas id massa nec felis dictum condimentum.</p>

  <div class="home-stripe">
    <h1>NEW COLLECTION FALL-WINTER '19 // NEW COLLECTION FALL-WINTER '19 // NEW COLLECTION FALL-WINTER '19 </h1>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/nosotros.blade.php ENDPATH**/ ?>