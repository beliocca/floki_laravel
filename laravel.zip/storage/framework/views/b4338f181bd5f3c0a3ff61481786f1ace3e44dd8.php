<?php $__env->startSection('title', '¡Contactános! - FLOKI Deco & Design'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/forms.css')); ?>"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

  <section class="section-contacto">
      <div class="register">
          <!--Imagen-->
          <article class="art1 d-none d-lg-block">
              <img src="images/living2.jpg" alt="living2" width="100%" height="859px" />
          </article>
          <!--Form-->
          <article class="art2">
              <form class="formulario" action="/contacto" method="post">
                <?php echo csrf_field(); ?>

                <?php if(Session::has('flash_message')): ?>
                  <p class="contactanos">
                    <?php echo e(Session::get('flash_message')); ?>

                  </p>
                  <?php else: ?>
                    <p class="contactanos">
                        ¡Contactanos!
                    </p>
                <?php endif; ?>

                  <p>
                    <input id="name" type="text" class="userform" name="name" value="<?php echo e(old('name')); ?>"
                        autocomplete="name" autofocus <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <?php if(isset($message)): ?> placeholder="<?php echo e($message); ?>"
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Nombre" <?php endif; ?>>
                  </p>
                  <p>
                    <input id="last_name" type="text" class="userform" name="last_name" value="<?php echo e(old('last_name')); ?>"
                        autocomplete="last_name" autofocus <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> <?php if(isset($message)): ?>
                        placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Apellido" <?php endif; ?>>
                  <p>
                    <input id="email" type="text" class="userform" name="email" value="<?php echo e(old('email')); ?>"
                        autocomplete="email" autofocus <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> <?php if(isset($message)): ?>
                        placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Email" <?php endif; ?>>
                  </p>
                  <p>
                    <textarea id="mensaje"  class="mensaje-contacto" name="mensaje" value="<?php echo e(old('mensaje')); ?>"
                        rows="8" cols="60"
                         <?php if ($errors->has('mensaje')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mensaje'); ?>
                           <?php if(isset($message)): ?>
                             placeholder="<?php echo e($message); ?>"
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          <?php else: ?>
                            placeholder="Escriba su mensaje aquí..."
                          <?php endif; ?>></textarea>
                  </p>

                  <p>
                      <button id="send-button" type="submit" >
                          <i class="far fa-paper-plane"></i> Enviar
                      </button>
                  </p>

                  <div class="contacto-mensaje-enviado">
                    <?php if(isset($mensajeEnviado)): ?>

                    <h3><?php echo e($mensajeEnviado); ?></h3>

                    <?php endif; ?>

                  </div>

              </form>


          </article>
      </div>
  </section>
  <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\floki_laravel\resources\views/contacto.blade.php ENDPATH**/ ?>