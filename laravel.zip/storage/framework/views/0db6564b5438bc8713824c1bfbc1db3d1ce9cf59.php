<?php $__env->startSection('title', 'Checkout - FLOKI Deco & Design'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/checkout.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1 class="titleperfil">Checkout</h1>

<div class="container-checkout"></div>

<div class="order-list">
    <h2>Productos</h2>
    <ul>
        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><span><?php echo e($cart["cantidad"]); ?> <?php echo e($cart["name"]); ?>

            </span><span>$<?php echo e($cart["price"]*$cart["cantidad"]); ?></span></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div>Total: $ <?php echo e($total); ?></div>
    </ul>
</div>

<div class="order-form">
    <form action="/order" method="POST">
        <?php echo csrf_field(); ?>
        <h2>Tus datos</h2>
        <div>
            <label for="name">Nombre</label>
            <input class="form-control " type="text" name="name">
        </div>
        <div>
            <label for="last_name">Apellido</label>
            <input class="form-control " type="text" name="last_name">
        </div>
        <div>
            <label for="email">email</label>
            <input class="form-control " type="email" value="" name="email">
        </div>
        <div>
            <label for="address_line1">Direccion</label>
            <input class="form-control " type="text" value="" name="address_line1">

            <input class="form-control" id="addressline2" type="text" value="" name="address_line2">
        </div>
        <div>
            <label for="city">Ciudad</label>
            <input class="form-control " type="text" value="" name="city">
        </div>
        <div>
            <label for="zipcode">Código postal</label>
            <input class="form-control " type="text" value="" name="zipcode">
        </div>
        <div>
            <label for="state">Provincia</label>
            <input class="form-control " type="text" value="" name="state">
        </div>
        <div>
            <label for="contry">Pais</label>
            <input class="form-control " type="text" value="" name="country">
        </div>


        <button class="btn-comprar button"  type="submit">Comprar</button>

    </form>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\floki_laravel\resources\views/checkoutguest.blade.php ENDPATH**/ ?>