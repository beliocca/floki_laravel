<h1>Hi, <?php echo e($name); ?></h1>
l<p>Sending Mail from Laravel.</p>
<?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/mail.blade.php ENDPATH**/ ?>