<?php $__env->startSection('title', 'Shop - FLOKI Deco & Design'); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/producto.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="contenedor-producto">

        <div class="fotos-producto">

             <div class="photo-product-main" >
               <i id="previousPhoto" class="fas fa-chevron-left"></i>
               <?php $__currentLoopData = $product->productPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productPhoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <img  class="productPhotos" src="/uploads/product_photos/<?php echo e($productPhoto->filename); ?>"
                             alt="">
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <i id="nextPhoto" class="fas fa-chevron-right"></i>
             </div>

        </div>

         <div class="datos-producto">
             <h1><?php echo e($product->name); ?></h1>

             <h2>$<?php echo e($product->price); ?></h2>

             <h3>Detalles del producto</h3>
             <p><?php echo e($product->description); ?></p>

             <p>STOCK: <?php echo e($product->stock); ?> unidades.</p>

             <form class="form-producto" action="/addtocart" method="post">
               <?php echo csrf_field(); ?>

               <div class="cantidad">
                 <h3>Cantidad: </h3>
                 <select name="cantidad">
                   <?php if($product->stock > 10): ?>
                     <option value="1" selected>1</option>
                     <?php for($i=2; $i < 11; $i++): ?>
                       <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                     <?php endfor; ?>

                  <?php elseif($product->stock > 0 && $product->stock <= 10): ?> {
                    <option value="1" selected>1</option>
                     <?php for($i=2; $i < $product->stock ; $i++): ?>
                       <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                     <?php endfor; ?>
                   }

                 <?php else: ?>{
                   <option value="0" selected>Sin stock</option>
                 }
                   <?php endif; ?>



                 </select>

               </div>

              <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
              <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
              <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
              <input type="hidden" name="photo" value="<?php echo e($product->productPhotos->first()->filename); ?>">

              <button type="submit" name="button">COMPRAR</button>
             </form>


             

         </div>

</div>



<div class="producto-recomendaciones">
  <div class="te-puede-gustar">
    <hr>
    <h1>También te puede gustar</h1>
  </div>

  <section class="productos-recomendados">
    <?php $__currentLoopData = $productsRecomendados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <article class="producto-recomendado">
        <div class="producto-recomendado-photo">

          <?php $__currentLoopData = $product->productPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productPhoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img  class="productPhotosHover" class="img-fluid" src="/uploads/product_photos/<?php echo e($productPhoto->filename); ?>"
                        alt="">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <h2><?php echo e($product->name); ?></h2>
        <h3>$<?php echo e($product->price); ?></h3>

        <a href="/product/<?php echo e($product->id); ?>">Ver más</a>
        
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/product.blade.php ENDPATH**/ ?>