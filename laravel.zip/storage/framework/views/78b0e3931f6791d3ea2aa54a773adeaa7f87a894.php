<?php $__env->startSection('title', 'Login - FLOKI Deco & Design'); ?>


<?php $__env->startSection('content'); ?>
  <section class="section-login">
      <div class="login">
          <!--Imagen-->
          <article class="art1 d-none d-lg-block">
              <img src="images/home-office.jpg" alt="living" width="100%" height="859px" />
          </article>
          <!--Form-->
          <article class="art2">
              <form class="formulario-login" action="<?php echo e(route('login')); ?>" method="post">
                  <?php echo csrf_field(); ?>

                  <p class="ingresa">
                      ¡Ingresá!
                  </p>
                  <div class="ingresarcon">
                      <article class="ing">
                          <i class="fab fa-google-plus-g"></i>
                      </article>
                      <article class="ing">
                          <i class="fab fa-facebook-f"></i>
                      </article>
                      <article class="ing">
                          <i class="fab fa-twitter"></i>
                      </article>
                  </div>

                  <div class="o-wrap">
                      <hr />
                      <i class="far fa-circle"></i>
                  </div>


                  <p>
                    <input id="email" type="email" class="userform" name="email" value="<?php echo e(old('email')); ?>"
                      autocomplete="email" autofocus

                      <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                         <?php if(isset($message)): ?>
                       placeholder="<?php echo e($message); ?>"
                         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                       <?php else: ?>
                         placeholder="Email"
                     <?php endif; ?>
                     >
                  </p>

                  <p>
                    <input id="password" type="password" class="userform" name="password"


                      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                         <?php if(isset($message)): ?>
                       placeholder="<?php echo e($message); ?>"
                         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                       <?php else: ?>
                         placeholder="Password"
                     <?php endif; ?>
                     >
                  </p>

                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                       <?php if(isset($message)): ?>
                       <p class="tyc">
                    <?php echo e($message); ?>

                </p>
                       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                     
                   <?php endif; ?>

                  <p>
                    <input class="tyc" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> />
                    <label for="remember">Recordarme</label>

                  </p>

                  <p>
                    <button id="send-button" type="submit" name="button" >
                        <i class="far fa-paper-plane"></i> Enviar
                    </button>
                  </p>

                  <div class="">
                    <?php if(Route::has('password.request')): ?>
                        <a class="tyc" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?>

                        </a>
                    <?php endif; ?>
                  </div>

                  </div>


              </form>
          </article>
      </div>
  </section>
  <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>