<?php $__env->startSection('title', '¡Registrate! - FLOKI Deco & Design'); ?>


<?php $__env->startSection('content'); ?>

<section class="section-registro">
    <div class="register">
        <!--Imagen-->
        <article class="art1 d-none d-lg-block">
            <img src="images/living.jpg" alt="living" width="100%" height="859px" />
        </article>
        <!--Form-->
        <article class="art2">
            <form class="formulario-registro" action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <p class="registrate">
                    ¡Registrate!
                </p>
                <div class="registrarsecon">
                    <article class="reg">
                        <i class="fab fa-google-plus-g"></i>
                    </article>
                    <article class="reg">
                        <i class="fab fa-facebook-f"></i>
                    </article>
                    <article class="reg">
                        <i class="fab fa-twitter"></i>
                    </article>
                </div>
                <div class="o-wrap2">
                    <hr />
                    <i class="far fa-circle"></i>
                </div>
                <p>
                    <input id="name" type="text" class="userform" name="name" value="<?php echo e(old('name')); ?>"
                        autocomplete="name" autofocus <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <?php if(isset($message)): ?> placeholder="<?php echo e($message); ?>"
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Nombre" <?php endif; ?>>
                </p>

                <p>
                    <input id="last_name" type="text" class="userform" name="last_name" value="<?php echo e(old('last_name')); ?>"
                        autocomplete="last_name" autofocus <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> <?php if(isset($message)): ?>
                        placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Apellido" <?php endif; ?>>
                </p>
                <p>
                    <input id="email" type="text" class="userform" name="email" value="<?php echo e(old('email')); ?>"
                        autocomplete="email" autofocus <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> <?php if(isset($message)): ?>
                        placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Email" <?php endif; ?>>
                </p>

                <p>
                    <input id="password" type="password" class="userform" name="password" data-toggle="tooltip"
                        data-placement="top" title="La contraseña debe tener al menos 8 caracteres"
                        autocomplete="new-password" <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> <?php if(isset($message)): ?>
                        placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Contraseña" <?php endif; ?>>
                </p>

                <p>
                    <input id="password-confirm" type="password" class="userform" name="password-confirmation"
                        autocomplete="new-password" <?php if ($errors->has('password-confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password-confirmation'); ?> <?php if(isset($message)): ?>
                        placeholder="<?php echo e($message); ?>" <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php else: ?> placeholder="Repita su contraseña" <?php endif; ?>>
                </p>

                <p>
                    <input type="hidden" name="newsletter" value=0>
                    <div ><input type="checkbox" name="newsletter" value=1>
                        <span class="tyc"> Deseo recibir novedades en mi email.</span>
                    </div>
                    <div >
                        <input id="tyc" type="checkbox" name="tyc">
                        <span class="tyc">Estoy de acuerdo con los <a href="#">términos y condiciones.</a></span>
                        <div><?php if ($errors->has('tyc')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tyc'); ?>
                        <small class="condiciones"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></div>
                    </div>
                    <input type="hidden" name="role" value="2">
                    <p>
                        <button id="send-button" type="submit" name="button">
                            <i class="far fa-paper-plane"></i> Enviar
                        </button>
                    </p>
            </form>
        </article>
    </div>
</section>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\floki_laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>