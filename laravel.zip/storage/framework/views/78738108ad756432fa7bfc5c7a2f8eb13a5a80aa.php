<?php $__env->startSection('title', 'Checkout - FLOKI Deco & Design'); ?>


<?php $__env->startSection('content'); ?>

<h1>ACÁ VA EL CHECKOUT</h1>

<?php if(Session::has('cart')): ?>

  <?php
      $cantidadProductos = 0;
      $precioTotal = 0;

      foreach (Session::get('cart') as $cartId => $product) {
        $cantidadProductos += $product['cantidad'];
        $precioTotal += $product['price'] * $product['cantidad'];
      }

  ?>

<div class="">
    <p><?php echo e($cantidadProductos); ?> Productos</p>

    <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartId => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
<?php echo e($product["cantidad"]); ?>x  <?php echo e($product["name"]); ?> $<?php echo e($product["price"] * $product["cantidad"]); ?>


<form class="" action="/borrarCartItem" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="cart-id" value="<?php echo e($cartId); ?>">
  <button type="submit" name="button">Borrar item</button>

</form>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <p>Total: $<?php echo e($precioTotal); ?></p>


</div>



<?php else: ?>
  <h1>No tiene productos en su carrito</h1>
<?php endif; ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/checkout.blade.php ENDPATH**/ ?>