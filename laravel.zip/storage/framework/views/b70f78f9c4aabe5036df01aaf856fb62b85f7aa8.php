<?php $__env->startSection('title', 'Checkout - FLOKI Deco & Design'); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/cart.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<h1 class="titleperfil">Carrito</h1>

<?php if(Session::has('cart')): ?>

<?php
$cantidadProductos = 0;
$precioTotal = 0;

foreach (Session::get('cart') as $cartId => $product) {
$cantidadProductos += $product['cantidad'];
$precioTotal += $product['price'] * $product['cantidad'];
}

?>

<table class="table table-hover table-responsive-sm">

    <thead class="thead-light">
        <tr>
            <th scope="col">Foto</th>
            <th scope="col">Nombre</th>
            <th scope="col">Cantidad</th>
            <th scope="col">precio  </th>
            <th scope="col"></th>
        </tr>
    </thead>

    <tbody class="thead-light">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['id']==$product->id): ?>
        <tr class="productorder">
            <input class="input-product-id" type="hidden" value=<?php echo e($product->id); ?>>
            <td> <img class="img-grid-admin"
                    src="/uploads/product_photos/<?php echo e($product->productPhotos->first()->filename); ?>" alt=""></td>
            <td><?php echo e($product->name); ?></td>
            <td><input class="cantidadproductos" type="number" value="<?php echo e($item['cantidad']); ?>"></td>
            <td class="precioporproducto"><?php echo e($product->price * $item['cantidad']); ?></td>
            <td><button class="btn-delete-out"><i class=" fas fa-times-circle"></i></button>
            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

<div class="divcheckout">Total: $ <span class="checkouttotal"><?php echo e($precioTotal); ?></span>
</div>

    <div class="buttonssubmit">
        <a href="/checkout"><button type="submit">Comprá como invitado</button></a>
        <a href=""><button type="submit">Comprá con tu cuenta</button></a>
    </div>



<?php else: ?>
<h1>No tiene productos en su carrito</h1>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/cart.blade.php ENDPATH**/ ?>