<?php $__env->startSection('title', 'Shop - FLOKI Deco & Design'); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/changePhotoOnHover.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="contenedor-shop">
    <div class="menu-shop">
        <ul class="sticky-menu-shop">
            <p>Categorias</p>
            <ul>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($category->is_main): ?>
                    <li>
                        <a href="/shop/<?php echo e($category->url); ?>"><?php echo e($category->name); ?></a>
                    </li>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li >
                      <a  href="/shop">Todas las categorias</a>
                    </li>
            </ul>

            <p>Ordenar por precio</p>
            <ul>
                <li>
                    <a href="/shop/order/asc">Menor a mayor</a>
                </li>
                <li>
                    <a href="/shop/order/desc">Mayor a menor</a>
                </li>
                <li>
                    <a href="/shop/order/5000">Hasta $5.000</a>
                </li>
            </ul>

        </ul>

    </div>

    <div class="menu-shop-mobile">

          <hr>
          <span class="">
              <a class="dropdown"
                  href="#"
                  id="shopCategorias"
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
              >Categorias</a>
                <ul class="dropdown-menu " aria-labelledby="shopCategorias">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($category->is_main): ?>
                        <li class="dropdown-item">
                            <a href="/shop/<?php echo e($category->url); ?>"><?php echo e($category->name); ?></a>
                        </li>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li  class="dropdown-item">
                          <a  href="/shop">Todas las categorias</a>
                        </li>
                </ul>
          </span>
          <span class="">
              <a class=" dropdown"
                href="#"
                id="ordenarPorPrecio"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
            >
            Ordenar por precio</a>
            <ul class="dropdown-menu " aria-labelledby="ordenarPorPrecio">
                <li class="dropdown-item">
                    <a href="/shop/order/asc">Menor a mayor</a>
                </li>
                <li class="dropdown-item">
                    <a href="/shop/order/desc">Mayor a menor</a>
                </li>
                <li class="dropdown-item">
                    <a href="/shop/order/5000">Hasta $5.000</a>
                </li>
            </ul>


        </span>



    </div>

    <div class="contenedor-productos">
        <section class="section-productos">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <article class="producto js-img-hover">
                      <div id="photo-shop" >
                        <?php $__currentLoopData = $product->productPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productPhoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <img  class="productPhotosHover" class="img-fluid" src="/uploads/product_photos/<?php echo e($productPhoto->filename); ?>"
                                      alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  <h2><?php echo e($product->name); ?></h2>

                  <h3>$<?php echo e($product->price); ?></h3>


                  <a href="/product/<?php echo e($product->id); ?>">Ver más!</a>

                  <form class="" action="/addtocart" method="post">
                    <?php echo csrf_field(); ?>


                   <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                    <input type="hidden" name="cantidad" value=1>
                   <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                   <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                   <input type="hidden" name="photo" value="<?php echo e($product->productPhotos->first()->filename); ?>">

                   <button type="submit" name="button">COMPRAR</button>
                  </form>
              </article>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </section>

          <div class="pagination-productos">
              <?php echo e($products->appends($_GET)->links()); ?>

          </div>

    </div>



</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/floki-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solbe\Desktop\DIGITAL HOUSE\FLOKI\floki_laravel\resources\views/shop.blade.php ENDPATH**/ ?>